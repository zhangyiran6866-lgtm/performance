import{a8 as e}from"./index-B7u2e9eb.js";const r=()=>e({url:"/system/dept/simple-list",method:"get"}),p=t=>e({url:"/system/user/selectUsersByDeptId",method:"post",data:t});export{r as a,p as g};
